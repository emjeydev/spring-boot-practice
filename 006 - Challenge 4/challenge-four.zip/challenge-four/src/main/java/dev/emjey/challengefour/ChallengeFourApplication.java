package dev.emjey.challengefour;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChallengeFourApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChallengeFourApplication.class, args);
	}

}
