package dev.emjey.challengesix;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChallengeSixApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChallengeSixApplication.class, args);
	}

}
