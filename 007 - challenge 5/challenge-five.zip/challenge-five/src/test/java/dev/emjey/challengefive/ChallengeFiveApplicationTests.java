package dev.emjey.challengefive;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChallengeFiveApplicationTests {

	@Test
	void contextLoads() {
	}

}
