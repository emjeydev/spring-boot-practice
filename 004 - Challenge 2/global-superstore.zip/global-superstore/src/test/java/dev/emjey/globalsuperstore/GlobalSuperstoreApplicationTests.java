package dev.emjey.globalsuperstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GlobalSuperstoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
