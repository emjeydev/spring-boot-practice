package dev.emjey.globalsuperstore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GlobalSuperstoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(GlobalSuperstoreApplication.class, args);
	}

}
