package dev.emjey.grade_submission;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GradeSubmissionApplicationTests {

	@Test
	void contextLoads() {
	}

}
