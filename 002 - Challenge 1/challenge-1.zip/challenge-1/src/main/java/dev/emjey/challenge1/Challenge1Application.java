package dev.emjey.challenge1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Challenge1Application {

	public static void main(String[] args) {
		SpringApplication.run(Challenge1Application.class, args);
	}

}
