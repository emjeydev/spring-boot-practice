package dev.emjey.simpole_form;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpoleFormApplicationTests {

	@Test
	void contextLoads() {
	}

}
