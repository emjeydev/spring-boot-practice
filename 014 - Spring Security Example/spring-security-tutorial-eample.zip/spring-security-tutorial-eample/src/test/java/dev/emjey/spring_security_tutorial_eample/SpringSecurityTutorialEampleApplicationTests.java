package dev.emjey.spring_security_tutorial_eample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityTutorialEampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
