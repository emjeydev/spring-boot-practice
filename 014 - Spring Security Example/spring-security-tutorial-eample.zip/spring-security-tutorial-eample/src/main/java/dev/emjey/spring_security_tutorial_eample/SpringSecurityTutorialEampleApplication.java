package dev.emjey.spring_security_tutorial_eample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityTutorialEampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityTutorialEampleApplication.class, args);
	}

}
