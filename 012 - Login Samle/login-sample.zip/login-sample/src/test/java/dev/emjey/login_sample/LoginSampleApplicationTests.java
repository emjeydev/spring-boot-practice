package dev.emjey.login_sample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginSampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
