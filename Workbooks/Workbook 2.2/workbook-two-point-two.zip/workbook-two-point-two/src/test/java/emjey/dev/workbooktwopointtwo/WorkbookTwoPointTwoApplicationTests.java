package emjey.dev.workbooktwopointtwo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkbookTwoPointTwoApplicationTests {

	@Test
	void contextLoads() {
	}

}
