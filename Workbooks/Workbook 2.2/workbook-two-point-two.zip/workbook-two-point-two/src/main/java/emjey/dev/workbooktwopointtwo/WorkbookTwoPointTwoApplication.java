package emjey.dev.workbooktwopointtwo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorkbookTwoPointTwoApplication {

	public static void main(String[] args) {
		SpringApplication.run(WorkbookTwoPointTwoApplication.class, args);
	}

}
