package dev.emjey.workbooktwopointseven;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorkbooktwopointsevenApplication {

	public static void main(String[] args) {
		SpringApplication.run(WorkbooktwopointsevenApplication.class, args);
	}

}
