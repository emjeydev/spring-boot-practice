package dev.emjey.workbooktwopointseven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkbooktwopointsevenApplicationTests {

	@Test
	void contextLoads() {
	}

}
