package dev.emjey.workbookeightpointthree;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorkbookEightPointThreeApplication {

	public static void main(String[] args) {
		SpringApplication.run(WorkbookEightPointThreeApplication.class, args);
	}

}
