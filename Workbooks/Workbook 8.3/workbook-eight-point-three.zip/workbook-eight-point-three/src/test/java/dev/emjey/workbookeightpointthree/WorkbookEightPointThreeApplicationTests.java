package dev.emjey.workbookeightpointthree;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkbookEightPointThreeApplicationTests {

	@Test
	void contextLoads() {
	}

}
