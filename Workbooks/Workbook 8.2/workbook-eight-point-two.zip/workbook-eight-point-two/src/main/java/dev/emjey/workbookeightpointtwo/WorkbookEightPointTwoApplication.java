package dev.emjey.workbookeightpointtwo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorkbookEightPointTwoApplication {

	public static void main(String[] args) {
		SpringApplication.run(WorkbookEightPointTwoApplication.class, args);
	}

}
