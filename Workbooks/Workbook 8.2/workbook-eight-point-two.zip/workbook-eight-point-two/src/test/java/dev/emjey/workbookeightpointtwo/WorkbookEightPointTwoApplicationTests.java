package dev.emjey.workbookeightpointtwo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkbookEightPointTwoApplicationTests {

	@Test
	void contextLoads() {
	}

}
