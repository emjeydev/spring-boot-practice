package dev.emjey.workbookthreepointone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkbookThreePointOneApplicationTests {

	@Test
	void contextLoads() {
	}

}
