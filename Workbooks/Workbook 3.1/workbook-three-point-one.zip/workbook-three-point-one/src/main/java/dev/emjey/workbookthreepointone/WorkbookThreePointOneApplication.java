package dev.emjey.workbookthreepointone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorkbookThreePointOneApplication {

	public static void main(String[] args) {
		SpringApplication.run(WorkbookThreePointOneApplication.class, args);
	}

}
