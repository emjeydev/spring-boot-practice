package dev.emjey.workbooktwopointten;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkbookTwoPointTenApplicationTests {

	@Test
	void contextLoads() {
	}

}
