package dev.emjey.workbookninepointone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorkbookNinePointOneApplication {

	public static void main(String[] args) {
		SpringApplication.run(WorkbookNinePointOneApplication.class, args);
	}

}
