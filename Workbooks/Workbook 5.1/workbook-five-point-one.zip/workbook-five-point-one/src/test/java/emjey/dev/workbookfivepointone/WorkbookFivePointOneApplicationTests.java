package emjey.dev.workbookfivepointone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkbookFivePointOneApplicationTests {

	@Test
	void contextLoads() {
	}

}
