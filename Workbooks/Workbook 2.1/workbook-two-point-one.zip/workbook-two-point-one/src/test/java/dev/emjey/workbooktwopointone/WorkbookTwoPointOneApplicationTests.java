package dev.emjey.workbooktwopointone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkbookTwoPointOneApplicationTests {

	@Test
	void contextLoads() {
	}

}
