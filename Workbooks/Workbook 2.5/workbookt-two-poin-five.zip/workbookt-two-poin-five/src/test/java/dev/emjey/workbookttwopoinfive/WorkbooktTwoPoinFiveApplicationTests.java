package dev.emjey.workbookttwopoinfive;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkbooktTwoPoinFiveApplicationTests {

	@Test
	void contextLoads() {
	}

}
