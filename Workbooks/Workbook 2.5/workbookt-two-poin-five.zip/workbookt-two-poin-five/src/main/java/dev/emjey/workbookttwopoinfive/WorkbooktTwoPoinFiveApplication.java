package dev.emjey.workbookttwopoinfive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorkbooktTwoPoinFiveApplication {

	public static void main(String[] args) {
		SpringApplication.run(WorkbooktTwoPoinFiveApplication.class, args);
	}

}
