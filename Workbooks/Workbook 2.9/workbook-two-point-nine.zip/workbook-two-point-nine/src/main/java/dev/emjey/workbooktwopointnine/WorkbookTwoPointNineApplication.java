package dev.emjey.workbooktwopointnine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorkbookTwoPointNineApplication {

	public static void main(String[] args) {
		SpringApplication.run(WorkbookTwoPointNineApplication.class, args);
	}

}
