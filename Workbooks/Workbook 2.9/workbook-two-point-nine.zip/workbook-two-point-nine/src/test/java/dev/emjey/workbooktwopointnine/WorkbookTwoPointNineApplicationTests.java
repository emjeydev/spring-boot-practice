package dev.emjey.workbooktwopointnine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkbookTwoPointNineApplicationTests {

	@Test
	void contextLoads() {
	}

}
