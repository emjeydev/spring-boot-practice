package dev.emjey.workbookeightpointone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorkbookEightPointOneApplication {

	public static void main(String[] args) {
		SpringApplication.run(WorkbookEightPointOneApplication.class, args);
	}

}
