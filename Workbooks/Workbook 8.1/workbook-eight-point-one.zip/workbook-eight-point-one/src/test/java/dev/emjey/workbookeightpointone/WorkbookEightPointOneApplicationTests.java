package dev.emjey.workbookeightpointone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkbookEightPointOneApplicationTests {

	@Test
	void contextLoads() {
	}

}
