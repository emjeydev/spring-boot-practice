package dev.emjey.workbookttwopoinsix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkbooktTwoPoinSixApplicationTests {

	@Test
	void contextLoads() {
	}

}
