package dev.emjey.workbooktwopointthreetoseven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkbookTwoPointThreeToSevenApplicationTests {

	@Test
	void contextLoads() {
	}

}
