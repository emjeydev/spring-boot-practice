package dev.emjey.workbooktwopointthreetoseven;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorkbookTwoPointThreeToSevenApplication {

	public static void main(String[] args) {
		SpringApplication.run(WorkbookTwoPointThreeToSevenApplication.class, args);
	}

}
